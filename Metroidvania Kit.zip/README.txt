==================================================
Dark Fantasy Metroidvania Asset Pack
Created by luem (Luciano)
==================================================

Thank you for downloading this asset pack!

[ENGLISH]
This package contains 2D pixel art assets designed for Metroidvania, Action RPG, and Platformer games:
- Dark Knight Character Sprite (idle state, split into body layers for custom animation/rigging).
- Complete UI Kit (health/mana bars in multiple colors, inventory frames, and potion slots).
- Items & Props (potions, sword, bow, shield, helmet, boots, crystal, and spellbook).
- Gothic Environment & Tileset (stone arches, pillars, overgrown roots, dead trees, and dark background).

LICENSE:
This asset pack is published under CC0 1.0 Universal (Public Domain).
- You CAN use these assets in personal and commercial projects.
- You CAN modify, adapt, and remix all assets.
- Credit is not required, but appreciated!

Check out how this kit was created on YouTube:
https://www.youtube.com/watch?v=rC-52tJY6QE

Portfolio & Links:
- Itch.io: https://luem.itch.io/
- YouTube: https://www.youtube.com/@LUEMart

--------------------------------------------------

[ESPAÑOL]
Este paquete contiene recursos de pixel art 2D diseñados para juegos estilo Metroidvania, RPG de acción y plataformas:
- Sprite de Caballero Oscuro (estado idle, separado en capas del cuerpo para rigging/animación personalizada).
- Kit de UI Completo (barras de vida/maná en varios colores, marcos de inventario y slots para pociones).
- Ítems y Props (pociones, espada, arco, escudo, casco, botas, cristal y libro de hechizos).
- Tileset y Entorno Gótico (arcos de piedra, columnas, raíces, árboles secos y fondo oscuro).

LICENCIA:
Publicado bajo CC0 1.0 Universal (Dominio Público).
- PODÉS usar estos recursos en proyectos personales y comerciales.
- PODÉS modificar, adaptar y editar todos los sprites.
- No se requiere crédito, ¡pero se agradece!

Sigue mi trabajo:
- Itch.io: https://luem.itch.io/
- YouTube: https://www.youtube.com/@LUEMart
==================================================